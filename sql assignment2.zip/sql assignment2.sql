CREATE DATABASE sql_project;
USE sql_project;
CREATE TABLE Students (
    student_id INT PRIMARY KEY,
    name VARCHAR(100),
    city VARCHAR(50),
    Phone INT
);
SELECT * FROM Students ;
Create Table  Teachers(
teacher_id int,
teacher_name varchar (50),
expertise varchar(50),
base_city varchar(50),
monthly_salary int
);
SELECT * FROM teachers ;
Create table course(
course_id int,
course_name varchar(100),
duration_weeks int,
price int);
SELECT * FROM course ;
Create Table batches(
batch_id int,
course_id int,
teacher_id int,
starte_date date,
date_per_week int,
teme_slot time
);
SELECT * FROM batches ;
drop table batches;
Create Table batches(
batch_id int,
course_id int,
teacher_id int,
starte_date date,
date_per_week int,
teme_slot varchar(50)
);
select*from batches;
Create Table  enrollments(
enroll_id int,
student_id int,
batch_id int,
enroll_date date
);
select*from enrollments;
create table payments(
payment_id int,
enrollment_id int,
payment_date date,
amount int,
mode varchar (50)
);
select*from payments;
create table sessions(
session_id int,
batch_id int,
session_date date,
topic varchar(100)
);
select *from sessions;
create table Attendence(
 session_id int,
 student_id int,
 present int
 );
select*from Attendence;

---- total Number of students------
select count(*) as total_students
from students;


###city wise student count

select city, COUNT(*) AS cnt
FROM Students
GROUP BY city
ORDER BY cnt DESC;

#### Total revenue collected
SELECT SUM(amount) AS total_revenue
FROM Payments;

### Monthly revenue 
SELECT DATE_FORMAT(payment_date, '%Y-%m') AS month,
       SUM(amount) AS revenue
FROM Payments
GROUP BY month
ORDER BY month;


###Outstanding by enrollment

USE sql_project;
SHOW TABLES;
DESCRIBE enrollments;


SELECT * FROM enrollments LIMIT 5;

SELECT * FROM course LIMIT 5;

SELECT 
    e.enroll_id,
    c.course_name,
    c.price,
    IFNULL(SUM(p.amount), 0) AS total_paid,
    c.price - IFNULL(SUM(p.amount), 0) AS outstanding

FROM enrollments e

JOIN batches b 
    ON e.batch_id = b.batch_id

JOIN course c 
    ON b.course_id = c.course_id

LEFT JOIN payments p 
    ON e.enroll_id = p.enrollment_id

GROUP BY e.enroll_id, c.course_name, c.price;

#### Top three course by revenue

SELECT 
    c.course_name,
    SUM(p.amount) AS revenue

FROM payments p

JOIN enrollments e 
    ON p.enrollment_id = e.enroll_id

JOIN batches b 
    ON e.batch_id = b.batch_id

JOIN course c 
    ON b.course_id = c.course_id

GROUP BY c.course_name
ORDER BY revenue DESC
LIMIT 3;

### Teacher with hightest revenue
SELECT 
    t.teacher_name,
    SUM(p.amount) AS revenue
FROM payments p
JOIN enrollments e 
    ON p.enrollment_id = e.enroll_id
JOIN batches b 
    ON e.batch_id = b.batch_id
JOIN course c 
    ON b.course_id = c.course_id
JOIN teachers t 
    ON b.teacher_id = t.teacher_id
GROUP BY t.teacher_id, t.teacher_name
ORDER BY revenue DESC
LIMIT 1;

### Average class size per batch

SELECT 
    batch_id,
    COUNT(student_id) AS class_size

FROM enrollments
GROUP BY batch_id;

##### Attendence Rate
SELECT 
    SUM(CASE WHEN present = '1' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS attendance_rate
FROM attendance;
RENAME TABLE attendence TO attendance;

###course with maximum enrollments
SELECT 
    c.course_name,
    COUNT(*) AS total_students

FROM enrollments e

JOIN batches b 
    ON e.batch_id = b.batch_id

JOIN course c 
    ON b.course_id = c.course_id

GROUP BY c.course_name
ORDER BY total_students DESC
LIMIT 1;


#### students in multiple batches
SELECT 
    student_id,
    COUNT(batch_id) AS batch_count

FROM enrollments
GROUP BY student_id
HAVING COUNT(batch_id) >= 2;

###city with hightest revenue
SELECT 
    s.city,
    SUM(p.amount) AS revenue

FROM payments p

JOIN enrollments e 
    ON p.enrollment_id = e.enroll_id

JOIN students s 
    ON e.student_id = s.student_id

GROUP BY s.city
ORDER BY revenue DESC
LIMIT 1;

###Average Course fee
SELECT 
    course_name,
    AVG(price) AS avg_fee
FROM course
GROUP BY course_name;

### weekly enrollment trend
SELECT 
    YEARWEEK(enroll_date) AS week,
    COUNT(*) AS enrollments
FROM enrollments
GROUP BY week
ORDER BY week;

#####payment mode split
SELECT 
    mode,
    COUNT(*) * 100.0 / (SELECT COUNT(*) FROM payments) AS percentage
FROM payments
GROUP BY mode;


#### Teacher gross margin
SELECT 
    t.teacher_name,
    SUM(p.amount) - t.monthly_salary AS gross_margin
FROM teachers t
JOIN batches b 
    ON t.teacher_id = b.teacher_id
JOIN course c 
    ON b.course_id = c.course_id
JOIN enrollments e 
    ON b.batch_id = e.batch_id
JOIN payments p 
    ON e.enroll_id = p.enrollment_id
GROUP BY t.teacher_id, t.teacher_name, t.monthly_salary;

#### ontime payment rate
SELECT 
    SUM(CASE 
        WHEN DATEDIFF(p.payment_date, e.enroll_date) <= 14 
        THEN 1 ELSE 0 
    END) * 100.0 / COUNT(*) AS on_time_rate

FROM payments p
JOIN enrollments e 
    ON p.enrollment_id = e.enroll_id;
    
    
    ###Average revenue per student
    SELECT 
    SUM(p.amount) / COUNT(DISTINCT e.student_id) AS arpu
FROM payments p
JOIN enrollments e 
    ON p.enrollment_id = e.enroll_id;
    
    ##### Active student in last month
 SELECT 
    COUNT(DISTINCT a.student_id) AS active_students
FROM attendance a
JOIN sessions s 
    ON a.session_id = s.session_id
WHERE DATE_FORMAT(s.session_date, '%Y-%m') = (
    SELECT DATE_FORMAT(MAX(s2.session_date), '%Y-%m')
    FROM sessions s2
);





####Next class per batch
SELECT 
    batch_id,
    MIN(session_date) AS next_class
FROM sessions
WHERE session_date > CURDATE()
GROUP BY batch_id;
